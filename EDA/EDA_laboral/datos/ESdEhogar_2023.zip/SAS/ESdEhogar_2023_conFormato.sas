/************************************************************************
Instituto Nacional de Estad�stica (INE) www.ine.es
************************************************************************
 
DESCRIPCI�N:
Este programa genera un fichero SAS con formatos, partiendo de un fichero sin ellos.
 
Consta de las siguientes partes:
  * 1. Definir la librer�a de trabajo -->; Libname
  * 2. Definici�n de formatos -->; PROC FORMAT
  * 3. Vincular formatos a la base de datos -->; PASO data
 
 Entrada:
     - Fichero SAS sin formatos: ESdEhogar_2023.sas7bdat
 
 Salida:
     - Fichero SAS con formatos: ESdEhogar_2023_conFormato.sas7bdat
 
Donde:
	* Operaci�n: ESdE
	* Periodo: 2023
 
************************************************************************/
 
/* Directorio de trabajo para la operaci�n estad�stica */
*%let siglas_periodo = ESdEhogar_2023;
*%let conFormato = _conFormato;
 
/* 1) Definir la librer�a de trabajo: introducir el directorio que desee como librer�a 
(se da como ejemplo 'C:\Mis resultados'), y copiar en ese directorio el fichero sas ESdEhogar_2023.sas7bdat*/
 
*libname ROutput 'C:\Mis resultados';
 
options fmtsearch = (ROutput ROutput.cat1);
 
* 2) DEFINICI�N DE FORMATOS;
 
PROC FORMAT LIBRARY=ROutput.cat1; 
 
 * Tablas 1.........................;
value $TCCAA

"01"="Andaluc�a"
"02"="Arag�n"
"03"="Asturias, Principado de"
"04"="Balears, Illes"
"05"="Canarias"
"06"="Cantabria"
"07"="Castilla y Le�n"
"08"="Castilla - La Mancha"
"09"="Catalu�a"
"10"="Comunitat Valenciana"
"11"="Extremadura"
"12"="Galicia"
"13"="Madrid, Comunidad de"
"14"="Murcia, Regi�n de"
"15"="Navarra, Comunidad Foral de"
"16"="Pa�s Vasco"
"17"="Rioja, La"
"18"="Ceuta"
"19"="Melilla"
;
value $TESTRAT

"0"="Municipios de m�s de 500.000 habitantes"
"1"="Municipio capital de provincia (excepto los anteriores)"
"2"="Municipios con m�s de 100.000 habitantes (excepto los anteriores)"
"3"="Municipios de 50.000 a 100.000 habitantes (excepto los anteriores)"
"4"="Municipios de 20.000 a 50.000 habitantes (excepto los anteriores)"
"5"="Municipios de 10.000 a 20.000 habitantes"
"6"="Municipios con menos de 10.000 habitantes"
;
value $TSEXO

"1"="Hombre"
"2"="Mujer"
;
value $T8A

"01"="Adulto seleccionado (a.s.)"
"02"="C�nyuge o pareja del adulto seleccionado"
"03"="Hijo/a o hijastro/a (del adulto seleccionado o pareja del mismo)"
"04"="Yerno, nuera (o pareja del hijo/a o hijastro/a)"
"05"="Nieto/a o nieto/a pol�tico o pareja del mismo"
"06"="Padre, madre, suegro, suegra (o pareja de los mismos)"
"07"="Hermano/a"
"08"="Otro pariente del adulto seleccionado (o de la pareja del mismo)"
"09"="Persona del servicio dom�stico"
"10"="Sin parentesco con el adulto seleccionado"
;
value $T5A_otr

"1"="Otro familiar no miembro del hogar"
"2"="Un cuidador personal"
"3"="Un empleado/a del servicio dom�stico"
"4"="Servicios Sociales"
"5"="Otros (un vecino, el portero, etc.)"
"8"="No sabe"
"9"="No contesta"
;
value $T10A

"01"="No procede, es menor de 10 a�os"
"02"="No sabe leer o escribir"
"03"="Educaci�n Primaria incompleta (Ha asistido menos de 5 a�os a la escuela)"
"04"="Educaci�n Primaria completa"
"05"="Primera etapa de Ense�anza Secundaria, con o sin t�tulo (2� ESO aprobado, EGB, Bachillerato Elemental)"
"06"="Estudios de Bachillerato"
"07"="Ense�anzas profesionales de grado medio o equivalentes"
"08"="Ense�anzas profesionales de grado superior o equivalentes"
"09"="Estudios universitarios o equivalentes"
"98"="No sabe"
"99"="No contesta"
;
value $T11A

"1"="Trabajando"
"2"="En desempleo"
"3"="Jubilado/a, prejubilado/a"
"4"="Estudiando"
"5"="Incapacitado/a para trabajar"
"6"="Las labores del hogar"
"7"="Otros"
"9"="No contesta"
;
value $T12A

"1"="Hogar unipersonal"
"2"="Pareja sola"
"3"="Pareja con alg�n hijo menor de 25 a�os"
"4"="Pareja con todos los hijos de 25 o m�s a�os"
"5"="Padre o madre solo, con alg�n hijo menor de 25 a�os"
"6"="Padre o madre solo, con todos los hijos de 25 o m�s a�os"
"7"="Pareja o padre o madre solo, con alg�n hijo menor de 25 a�os y otras personas viviendo en el hogar"
"8"="Otro tipo de hogar"
;
value $T13B

"1"="S�, por cotizaci�n propia"
"2"="S�, por cotizaci�n de otra persona (pensiones de viudedad, orfandad, etc.)"
"3"="S�, por ambos tipos de cotizaci�n"
"4"="No"
"8"="No sabe"
"9"="No contesta"
;
value $T17B

"1"="Asalariado/a (a sueldo, comisi�n, jornal...)"
"2"="Empresario/a o profesional con asalariados"
"3"="Empresario/a sin asalariados o trabajador/a independiente"
"4"="Ayuda familiar (sin remuneraci�n reglamentada en la empresa o negocio de un familiar)"
"5"="Miembro de una cooperativa"
"6"="Otra situaci�n"
"8"="No sabe"
"9"="No contesta"
;
value $T21aB

"1"="Asalariado/a (a sueldo, comisi�n, jornal...)"
"2"="Empresario/a o profesional con asalariados"
"3"="Empresario/a sin asalariados o trabajador/a independiente"
"4"="Ayuda familiar (sin remuneraci�n reglamentada en la empresa o negocio de un familiar)"
"5"="Miembro de una cooperativa"
"6"="Otra situaci�n"
"8"="No sabe"
"9"="No contesta"
;
value $T21bB

"1"="Asalariado/a (a sueldo, comisi�n, jornal...)"
"2"="Empresario/a o profesional con asalariados"
"3"="Empresario/a sin asalariados o trabajador/a independiente"
"4"="Ayuda familiar (sin remuneraci�n reglamentada en la empresa o negocio de un familiar)"
"5"="Miembro de una cooperativa"
"6"="Otra situaci�n"
"8"="No sabe"
"9"="No contesta"
;
value $TCLASE

"1"="Directores/as y gerentes de establecimientos de 10 o m�s asalariados/as y profesionales tradicionalmente asociados/as a las licenciaturas universitarias"
"2"="Directores/as y gerentes de establecimientos de menos de 10 asalariados/ as y profesionales tradicionalmente asociados/as a diplomaturas universitarias y otros/as profesionales de apoyo t�cnico. Deportistas y artistas"
"3"="Ocupaciones intermedias y trabajadores/as por cuenta propia"
"4"="Supervisores/as y trabajadores/as en ocupaciones t�cnicas cualificadas"
"5"="Trabajadores/as cualificados/as del sector primario y otros/as trabajadores/as semi-cualificados/as"
"6"="Trabajadores/as no cualificados/as"
"8"="No sabe"
"9"="No contesta"
;
value $T24D

"1"="Ingresos del trabajo (por cuenta propia o ajena)"
"2"="Prestaci�n y subsidios por desempleo"
"3"="Pensi�n por jubilaci�n o viudedad"
"4"="Pensi�n por invalidez o incapacidad"
"5"="Prestaciones econ�micas por hijo/a a cargo, ayudas a la familia..."
"6"="Prestaciones o subvenciones relacionadas con la vivienda"
"7"="Prestaciones o subvenciones relacionadas con la educaci�n"
"8"="Otros ingresos regulares / Otro subsidio o prestaci�n social regular"
;
value $TINGRES

"01"="Menos de 1100 euros"
"02"="De 1100 a menos de 1650 euros"
"03"="De 1650 a menos de 2300 euros"
"04"="De 2300 a menos de 3800euros"
"05"="De 3800 euros en adelante"
"99"="No contesta"
;
value $TSINO

"1"="S�"
"2"="No"
;
value $TSINOC

"1"="S�"
"2"="No"
"9"="No contesta"
;
value $TVIV

"1"="Mucho"
"2"="Algo"
"3"="Nada"
"9"="No contesta"
;

* Tablas 2.........................;
value $T16CNO

"001"="Oficiales y suboficiales de las fuerzas armadas"
"002"="Tropa y mariner�a de las fuerzas armadas"
"111"="Miembros del poder ejecutivo y de los cuerpos legislativos; directivos de la Administraci�n P�blica y organizaciones de inter�s social"
"112"="Directores generales y presidentes ejecutivos"
"121"="Directores de departamentos administrativos"
"122"="Directores comerciales, de publicidad, relaciones p�blicas y de investigaci�n y desarrollo"
"131"="Directores de producci�n de explotaciones agropecuarias, forestales y pesqueras, y de industrias manufactureras, de miner�a, construcci�n y distribuci�n"
"132"="Directores de servicios de tecnolog�as de la informaci�n y las comunicaciones (TIC) y de empresas de servicios profesionales"
"141"="Directores y gerentes de empresas de alojamiento"
"142"="Directores y gerentes de empresas de restauraci�n"
"143"="Directores y gerentes de empresas de comercio al por mayor y al por menor"
"150"="Directores y gerentes de otras empresas de servicios no clasificados bajo otros ep�grafes"
"211"="M�dicos"
"212"="Profesionales de enfermer�a y parter�a"
"213"="Veterinarios"
"214"="Farmac�uticos"
"215"="Otros profesionales de la salud"
"221"="Profesores de universidades y otra ense�anza superior (excepto formaci�n profesional)"
"222"="Profesores de formaci�n profesional (materias espec�ficas)"
"223"="Profesores de ense�anza secundaria (excepto materias espec�ficas de formaci�n profesional)"
"224"="Profesores de ense�anza primaria"
"225"="Maestros y educadores de ense�anza infantil"
"231"="Profesores y t�cnicos de educaci�n especial"
"232"="Otros profesores y profesionales de la ense�anza"
"241"="F�sicos, qu�micos, matem�ticos y afines"
"242"="Profesionales en ciencias naturales"
"243"="Ingenieros (excepto ingenieros agr�nomos, de montes, el�ctricos, electr�nicos y TIC)"
"244"="Ingenieros el�ctricos, electr�nicos y de telecomunicaciones"
"245"="Arquitectos, urbanistas e ingenieros ge�grafos"
"246"="Ingenieros t�cnicos (excepto agr�colas, forestales, el�ctricos, electr�nicos y TIC)"
"247"="Ingenieros t�cnicos en electricidad, electr�nica y telecomunicaciones"
"248"="Arquitectos t�cnicos, top�grafos y dise�adores"
"251"="Jueces, magistrados, abogados y fiscales"
"259"="Otros profesionales del derecho"
"261"="Especialistas en finanzas"
"262"="Especialistas en organizaci�n y administraci�n"
"263"="T�cnicos de empresas y actividades tur�sticas"
"264"="Profesionales de ventas t�cnicas y m�dicas (excepto las TIC)"
"265"="Otros profesionales de las ventas, la comercializaci�n, la publicidad y las relaciones p�blicas"
"271"="Analistas y dise�adores de software y multimedia"
"272"="Especialistas en bases de datos y en redes inform�ticas"
"281"="Economistas"
"282"="Soci�logos, historiadores, psic�logos y otros profesionales en ciencias sociales"
"283"="Sacerdotes de las distintas religiones"
"291"="Archivistas, bibliotecarios, conservadores y afines"
"292"="Escritores, periodistas y ling�istas"
"293"="Artistas creativos e interpretativos"
"311"="Delineantes y dibujantes t�cnicos"
"312"="T�cnicos de las ciencias f�sicas, qu�micas, medioambientales y de las ingenier�as"
"313"="T�cnicos en control de procesos"
"314"="T�cnicos de las ciencias naturales y profesionales auxiliares afines"
"315"="Profesionales en navegaci�n mar�tima y aeron�utica"
"316"="T�cnicos de control de calidad de las ciencias f�sicas, qu�micas y de las ingenier�as"
"320"="Supervisores en ingenier�a de minas, de industrias manufactureras y de la construcci�n"
"331"="T�cnicos sanitarios de laboratorio, pruebas diagn�sticas y pr�tesis"
"332"="Otros t�cnicos sanitarios"
"333"="Profesionales de las terapias alternativas"
"340"="Profesionales de apoyo en finanzas y matem�ticas"
"351"="Agentes y representantes comerciales"
"352"="Otros agentes comerciales"
"353"="Agentes inmobiliarios y otros agentes"
"361"="Asistentes administrativos y especializados"
"362"="Agentes de aduanas, tributos y afines que trabajan en tareas propias de la Administraci�n P�blica"
"363"="T�cnicos de las fuerzas y cuerpos de seguridad"
"371"="Profesionales de apoyo de servicios jur�dicos y sociales"
"372"="Deportistas, entrenadores, instructores de actividades deportivas; monitores de actividades recreativas"
"373"="T�cnicos y profesionales de apoyo de actividades culturales, art�sticas y culinarias"
"381"="T�cnicos en operaciones de tecnolog�as de la informaci�n y asistencia al usuario"
"382"="Programadores inform�ticos"
"383"="T�cnicos en grabaci�n audiovisual, radiodifusi�n y telecomunicaciones"
"411"="Empleados contables y financieros"
"412"="Empleados de registro de materiales, de servicios de apoyo a la producci�n y al transporte"
"421"="Empleados de bibliotecas y archivos"
"422"="Empleados de servicios de correos, codificadores, correctores y servicios de personal"
"430"="Otros empleados administrativos sin tareas de atenci�n al p�blico"
"441"="Empleados de informaci�n y recepcionistas (excepto de hoteles)"
"442"="Empleados de agencias de viajes, recepcionistas de hoteles y telefonistas"
"443"="Agentes de encuestas"
"444"="Empleados de ventanilla y afines (excepto taquilleros)"
"450"="Empleados administrativos con tareas de atenci�n al p�blico no clasificados bajo otros ep�grafes"
"500"="Camareros y cocineros propietarios"
"511"="Cocineros asalariados"
"512"="Camareros asalariados"
"521"="Jefes de secci�n de tiendas y almacenes"
"522"="Vendedores en tiendas y almacenes"
"530"="Comerciantes propietarios de tiendas"
"541"="Vendedores en quioscos o en mercadillos"
"542"="Operadores de telemarketing"
"543"="Expendedores de gasolineras"
"549"="Otros vendedores"
"550"="Cajeros y taquilleros (excepto bancos)"
"561"="Auxiliares de enfermer�a"
"562"="T�cnicos auxiliares de farmacia y emergencias sanitarias y otros trabajadores de los cuidados a las personas en servicios de salud"
"571"="Trabajadores de los cuidados personales a domicilio (excepto cuidadores de ni�os)"
"572"="Cuidadores de ni�os"
"581"="Peluqueros y especialistas en tratamientos de est�tica, bienestar y afines"
"582"="Trabajadores que atienden a viajeros, gu�as tur�sticos y afines"
"583"="Supervisores de mantenimiento y limpieza de edificios, conserjes y mayordomos dom�sticos"
"584"="Trabajadores propietarios de peque�os alojamientos"
"589"="Otros trabajadores de servicios personales"
"591"="Guardias civiles"
"592"="Polic�as"
"593"="Bomberos"
"594"="Personal de seguridad privado"
"599"="Otros trabajadores de los servicios de protecci�n y seguridad"
"611"="Trabajadores cualificados en actividades agr�colas (excepto en huertas, invernaderos, viveros y jardines)"
"612"="Trabajadores cualificados en huertas, invernaderos, viveros y jardines"
"620"="Trabajadores cualificados en actividades ganaderas (incluidas av�colas, ap�colas y similares)"
"630"="Trabajadores cualificados en actividades agropecuarias mixtas"
"641"="Trabajadores cualificados en actividades forestales y del medio natural"
"642"="Trabajadores cualificados en actividades pesqueras y acuicultura"
"643"="Trabajadores cualificados en actividades cineg�ticas"
"711"="Trabajadores en hormig�n, encofradores, ferrallistas y afines"
"712"="Alba�iles, canteros, tronzadores, labrantes y grabadores de piedras"
"713"="Carpinteros (excepto ebanistas y montadores de estructuras met�licas)"
"719"="Otros trabajadores de las obras estructurales de construcci�n"
"721"="Escayolistas y aplicadores de revestimientos de pasta y mortero"
"722"="Fontaneros e instaladores de tuber�as"
"723"="Pintores, empapeladores y afines"
"724"="Soladores, colocadores de parquet y afines"
"725"="Mec�nicos-instaladores de refrigeraci�n y climatizaci�n"
"729"="Otros trabajadores de acabado en la construcci�n, instalaciones (excepto electricistas) y afines"
"731"="Moldeadores, soldadores, chapistas, montadores de estructuras met�licas y trabajadores afines"
"732"="Herreros y trabajadores de la fabricaci�n de herramientas y afines"
"740"="Mec�nicos y ajustadores de maquinaria"
"751"="Electricistas de la construcci�n y afines"
"752"="Otros instaladores y reparadores de equipos el�ctricos"
"753"="Instaladores y reparadores de equipos electr�nicos y de telecomunicaciones"
"761"="Mec�nicos de precisi�n en metales, ceramistas, vidrieros y artesanos"
"762"="Oficiales y operarios de las artes gr�ficas"
"770"="Trabajadores de la industria de la alimentaci�n, bebidas y tabaco"
"781"="Trabajadores que tratan la madera y afines"
"782"="Ebanistas y trabajadores afines"
"783"="Trabajadores del textil, confecci�n, piel, cuero y calzado"
"789"="Pegadores, buceadores, probadores de productos y otros operarios y artesanos diversos"
"811"="Operadores en instalaciones de la extracci�n y explotaci�n de minerales"
"812"="Operadores en instalaciones para el tratamiento de metales"
"813"="Operadores de instalaciones y m�quinas de productos qu�micos, farmac�uticos y materiales fotosensibles"
"814"="Operadores en instalaciones para el tratamiento y transformaci�n de la madera, la fabricaci�n de papel, productos de papel y caucho o materias pl�sticas"
"815"="Operadores de m�quinas para fabricar productos textiles y art�culos de piel y de cuero"
"816"="Operadores de m�quinas para elaborar productos alimenticios, bebidas y tabaco"
"817"="Operadores de m�quinas de lavander�a y tintorer�a"
"819"="Otros operadores de instalaciones y maquinaria fijas"
"820"="Montadores y ensambladores en f�bricas"
"831"="Maquinistas de locomotoras y afines"
"832"="Operadores de maquinaria agr�cola y forestal m�vil"
"833"="Operadores de otras m�quinas m�viles"
"834"="Marineros de puente, marineros de m�quinas y afines"
"841"="Conductores de autom�viles, taxis y furgonetas"
"842"="Conductores de autobuses y tranv�as"
"843"="Conductores de camiones"
"844"="Conductores de motocicletas y ciclomotores"
"910"="Empleados dom�sticos"
"921"="Personal de limpieza de oficinas, hoteles y otros establecimientos similares"
"922"="Limpiadores de veh�culos, ventanas y personal de limpieza a mano"
"931"="Ayudantes de cocina"
"932"="Preparadores de comidas r�pidas"
"941"="Vendedores callejeros"
"942"="Repartidores de publicidad, limpiabotas y otros trabajadores de oficios callejeros"
"943"="Ordenanzas, mozos de equipaje, repartidores a pie y afines"
"944"="Recogedores de residuos, clasificadores de desechos, barrenderos y afines"
"949"="Otras ocupaciones elementales"
"951"="Peones agr�colas"
"952"="Peones ganaderos"
"953"="Peones agropecuarios"
"954"="Peones de la pesca, la acuicultura, forestales y de la caza"
"960"="Peones de la construcci�n y de la miner�a"
"970"="Peones de las industrias manufactureras"
"981"="Peones del transporte, descargadores y afines"
"982"="Reponedores"
"000"="No contesta"
;

* Tablas 3.........................;
value $T15CNAE

"011"="Cultivos no perennes"
"012"="Cultivos perennes"
"013"="Propagaci�n de plantas"
"014"="Producci�n ganadera"
"015"="Producci�n agr�cola combinada con la producci�n ganadera"
"016"="Actividades de apoyo a la agricultura, a la ganader�a y de preparaci�n posterior a la cosecha"
"017"="Caza, captura de animales y servicios relacionados con las mismas"
"021"="Silvicultura y otras actividades forestales"
"022"="Explotaci�n de la madera"
"023"="Recolecci�n de productos silvestres, excepto madera"
"024"="Servicios de apoyo a la silvicultura"
"031"="Pesca"
"032"="Acuicultura"
"051"="Extracci�n de antracita y hulla"
"052"="Extracci�n de lignito"
"061"="Extracci�n de crudo de petr�leo"
"062"="Extracci�n de gas natural"
"071"="Extracci�n de minerales de hierro"
"072"="Extracci�n de minerales met�licos no f�rreos"
"081"="Extracci�n de piedra, arena y arcilla"
"089"="Industrias extractivas n.c.o.p."
"091"="Actividades de apoyo a la extracci�n de petr�leo y gas natural"
"099"="Actividades de apoyo a otras industrias extractivas"
"101"="Procesado y conservaci�n de carne y elaboraci�n de productos c�rnicos"
"102"="Procesado y conservaci�n de pescados, crust�ceos y moluscos"
"103"="Procesado y conservaci�n de frutas y hortalizas"
"104"="Fabricaci�n de aceites y grasas vegetales y animales"
"105"="Fabricaci�n de productos l�cteos"
"106"="Fabricaci�n de productos de moliner�a, almidones y productos amil�ceos"
"107"="Fabricaci�n de productos de panader�a y pastas alimenticias"
"108"="Fabricaci�n de otros productos alimenticios"
"109"="Fabricaci�n de productos para la alimentaci�n animal"
"110"="Fabricaci�n de bebidas"
"120"="Industria del tabaco"
"131"="Preparaci�n e hilado de fibras textiles"
"132"="Fabricaci�n de tejidos textiles"
"133"="Acabado de textiles"
"139"="Fabricaci�n de otros productos textiles"
"141"="Confecci�n de prendas de vestir, excepto de peleter�a"
"142"="Fabricaci�n de art�culos de peleter�a"
"143"="Confecci�n de prendas de vestir de punto"
"151"="Preparaci�n, curtido y acabado del cuero; fabricaci�n de art�culos de marroquiner�a, viaje y de guarnicioner�a y talabarter�a; preparaci�n y te�ido de pieles"
"152"="Fabricaci�n de calzado"
"161"="Aserrado y cepillado de la madera"
"162"="Fabricaci�n de productos de madera, corcho, cester�a y esparter�a"
"171"="Fabricaci�n de pasta papelera, papel y cart�n"
"172"="Fabricaci�n de art�culos de papel y de cart�n"
"181"="Artes gr�ficas y servicios relacionados con las mismas"
"182"="Reproducci�n de soportes grabados"
"191"="Coquer�as"
"192"="Refino de petr�leo"
"201"="Fabricaci�n de productos qu�micos b�sicos, compuestos nitrogenados, fertilizantes, pl�sticos y caucho sint�tico en formas primarias"
"202"="Fabricaci�n de pesticidas y otros productos agroqu�micos"
"203"="Fabricaci�n de pinturas, barnices y revestimientos similares; tintas de imprenta y masillas"
"204"="Fabricaci�n de jabones, detergentes y otros art�culos de limpieza y abrillantamiento; fabricaci�n de perfumes y cosm�ticos"
"205"="Fabricaci�n de otros productos qu�micos"
"206"="Fabricaci�n de fibras artificiales y sint�ticas"
"211"="Fabricaci�n de productos farmac�uticos de base"
"212"="Fabricaci�n de especialidades farmac�uticas"
"221"="Fabricaci�n de productos de caucho"
"222"="Fabricaci�n de productos de pl�stico"
"231"="Fabricaci�n de vidrio y productos de vidrio"
"232"="Fabricaci�n de productos cer�micos refractarios"
"233"="Fabricaci�n de productos cer�micos para la construcci�n"
"234"="Fabricaci�n de otros productos cer�micos"
"235"="Fabricaci�n de cemento, cal y yeso"
"236"="Fabricaci�n de elementos de hormig�n, cemento y yeso"
"237"="Corte, tallado y acabado de la piedra"
"239"="Fabricaci�n de productos abrasivos y productos minerales no met�licos n.c.o.p."
"241"="Fabricaci�n de productos b�sicos de hierro, acero y ferroaleaciones"
"242"="Fabricaci�n de tubos, tuber�as, perfiles huecos y sus accesorios, de acero"
"243"="Fabricaci�n de otros productos de primera transformaci�n del acero"
"244"="Producci�n de metales preciosos y de otros metales no f�rreos"
"245"="Fundici�n de metales"
"251"="Fabricaci�n de elementos met�licos para la construcci�n"
"252"="Fabricaci�n de cisternas, grandes dep�sitos y contenedores de metal"
"253"="Fabricaci�n de generadores de vapor, excepto calderas de calefacci�n central"
"254"="Fabricaci�n de armas y municiones"
"255"="Forja, estampaci�n y embutici�n de metales; metalurgia de polvos"
"256"="Tratamiento y revestimiento de metales; ingenier�a mec�nica por cuenta de terceros"
"257"="Fabricaci�n de art�culos de cuchiller�a y cuberter�a, herramientas y ferreter�a"
"259"="Fabricaci�n de otros productos met�licos"
"261"="Fabricaci�n de componentes electr�nicos y circuitos impresos ensamblados"
"262"="Fabricaci�n de ordenadores y equipos perif�ricos"
"263"="Fabricaci�n de equipos de telecomunicaciones"
"264"="Fabricaci�n de productos electr�nicos de consumo"
"265"="Fabricaci�n de instrumentos y aparatos de medida, verificaci�n y navegaci�n; fabricaci�n de relojes"
"266"="Fabricaci�n de equipos de radiaci�n, electrom�dicos y electroterap�uticos"
"267"="Fabricaci�n de instrumentos de �ptica y equipo fotogr�fico"
"268"="Fabricaci�n de soportes magn�ticos y �pticos"
"271"="Fabricaci�n de motores, generadores y transformadores el�ctricos, y de aparatos de distribuci�n y control el�ctrico"
"272"="Fabricaci�n de pilas y acumuladores el�ctricos"
"273"="Fabricaci�n de cables y dispositivos de cableado"
"274"="Fabricaci�n de l�mparas y aparatos el�ctricos de iluminaci�n"
"275"="Fabricaci�n de aparatos dom�sticos"
"279"="Fabricaci�n de otro material y equipo el�ctrico"
"281"="Fabricaci�n de maquinaria de uso general"
"282"="Fabricaci�n de otra maquinaria de uso general"
"283"="Fabricaci�n de maquinaria agraria y forestal"
"284"="Fabricaci�n de m�quinas herramienta para trabajar el metal y otras m�quinas herramienta"
"289"="Fabricaci�n de otra maquinaria para usos espec�ficos"
"291"="Fabricaci�n de veh�culos de motor"
"292"="Fabricaci�n de carrocer�as para veh�culos de motor; fabricaci�n de remolques y semirremolques"
"293"="Fabricaci�n de componentes, piezas y accesorios para veh�culos de motor"
"301"="Construcci�n naval"
"302"="Fabricaci�n de locomotoras y material ferroviario"
"303"="Construcci�n aeron�utica y espacial y su maquinaria"
"304"="Fabricaci�n de veh�culos militares de combate"
"309"="Fabricaci�n de otro material de transporte n.c.o.p."
"310"="Fabricaci�n de muebles"
"321"="Fabricaci�n de art�culos de joyer�a, bisuter�a y similares"
"322"="Fabricaci�n de instrumentos musicales"
"323"="Fabricaci�n de art�culos de deporte"
"324"="Fabricaci�n de juegos y juguetes"
"325"="Fabricaci�n de instrumentos y suministros m�dicos y odontol�gicos"
"329"="Industrias manufactureras n.c.o.p."
"331"="Reparaci�n de productos met�licos, maquinaria y equipo"
"332"="Instalaci�n de m�quinas y equipos industriales"
"351"="Producci�n, transporte y distribuci�n de energ�a el�ctrica"
"352"="Producci�n de gas; distribuci�n por tuber�a de combustibles gaseosos"
"353"="Suministro de vapor y aire acondicionado"
"360"="Captaci�n, depuraci�n y distribuci�n de agua"
"370"="Recogida y tratamiento de aguas residuales"
"381"="Recogida de residuos"
"382"="Tratamiento y eliminaci�n de residuos"
"383"="Valorizaci�n"
"390"="Actividades de descontaminaci�n y otros servicios de gesti�n de residuos"
"411"="Promoci�n inmobiliaria"
"412"="Construcci�n de edificios"
"421"="Construcci�n de carreteras y v�as f�rreas, puentes y t�neles"
"422"="Construcci�n de redes"
"429"="Construcci�n de otros proyectos de ingenier�a civil"
"431"="Demolici�n y preparaci�n de terrenos"
"432"="Instalaciones el�ctricas, de fontaner�a y otras instalaciones en obras de construcci�n"
"433"="Acabado de edificios"
"439"="Otras actividades de construcci�n especializada"
"451"="Venta de veh�culos de motor"
"452"="Mantenimiento y reparaci�n de veh�culos de motor"
"453"="Comercio de repuestos y accesorios de veh�culos de motor"
"454"="Venta, mantenimiento y reparaci�n de motocicletas y de sus repuestos y accesorios"
"461"="Intermediarios del comercio"
"462"="Comercio al por mayor de materias primas agrarias y de animales vivos"
"463"="Comercio al por mayor de productos alimenticios, bebidas y tabaco"
"464"="Comercio al por mayor de art�culos de uso dom�stico"
"465"="Comercio al por mayor de equipos para las tecnolog�as de la informaci�n y las comunicaciones"
"466"="Comercio al por mayor de otra maquinaria, equipos y suministros"
"467"="Otro comercio al por mayor especializado"
"469"="Comercio al por mayor no especializado"
"471"="Comercio al por menor en establecimientos no especializados"
"472"="Comercio al por menor de productos alimenticios, bebidas y tabaco en establecimientos especializados"
"473"="Comercio al por menor de combustible para la automoci�n en establecimientos especializados"
"474"="Comercio al por menor de equipos para las tecnolog�as de la informaci�n y las comunicaciones en establecimientos especializados"
"475"="Comercio al por menor de otros art�culos de uso dom�stico en establecimientos especializados"
"476"="Comercio al por menor de art�culos culturales y recreativos en establecimientos especializados"
"477"="Comercio al por menor de otros art�culos en establecimientos especializados"
"478"="Comercio al por menor en puestos de venta y en mercadillos"
"479"="Comercio al por menor no realizado ni en establecimientos, ni en puestos de venta ni en mercadillos"
"491"="Transporte interurbano de pasajeros por ferrocarril"
"492"="Transporte de mercanc�as por ferrocarril"
"493"="Otro transporte terrestre de pasajeros"
"494"="Transporte de mercanc�as por carretera y servicios de mudanza"
"495"="Transporte por tuber�a"
"501"="Transporte mar�timo de pasajeros"
"502"="Transporte mar�timo de mercanc�as"
"503"="Transporte de pasajeros por v�as navegables interiores"
"504"="Transporte de mercanc�as por v�as navegables interiores"
"511"="Transporte a�reo de pasajeros"
"512"="Transporte a�reo de mercanc�as y transporte espacial"
"521"="Dep�sito y almacenamiento"
"522"="Actividades anexas al transporte"
"531"="Actividades postales sometidas a la obligaci�n del servicio universal"
"532"="Otras actividades postales y de correos"
"551"="Hoteles y alojamientos similares"
"552"="Alojamientos tur�sticos y otros alojamientos de corta estancia"
"553"="Campings y aparcamientos para caravanas"
"559"="Otros alojamientos"
"561"="Restaurantes y puestos de comidas"
"562"="Provisi�n de comidas preparadas para eventos y otros servicios de comidas"
"563"="Establecimientos de bebidas"
"581"="Edici�n de libros, peri�dicos y otras actividades editoriales"
"582"="Edici�n de programas inform�ticos"
"591"="Actividades cinematogr�ficas, de v�deo y de programas de televisi�n"
"592"="Actividades de grabaci�n de sonido y edici�n musical"
"601"="Actividades de radiodifusi�n"
"602"="Actividades de programaci�n y emisi�n de televisi�n"
"611"="Telecomunicaciones por cable"
"612"="Telecomunicaciones inal�mbricas"
"613"="Telecomunicaciones por sat�lite"
"619"="Otras actividades de telecomunicaciones"
"620"="Programaci�n, consultor�a y otras actividades relacionadas con la inform�tica"
"631"="Proceso de datos, hosting y actividades relacionadas; portales web"
"639"="Otros servicios de informaci�n"
"641"="Intermediaci�n monetaria"
"642"="Actividades de las sociedades holding"
"643"="Inversi�n colectiva, fondos y entidades financieras similares"
"649"="Otros servicios financieros, excepto seguros y fondos de pensiones"
"651"="Seguros"
"652"="Reaseguros"
"653"="Fondos de pensiones"
"661"="Actividades auxiliares a los servicios financieros, excepto seguros y fondos de pensiones"
"662"="Actividades auxiliares a seguros y fondos de pensiones"
"663"="Actividades de gesti�n de fondos"
"681"="Compraventa de bienes inmobiliarios por cuenta propia"
"682"="Alquiler de bienes inmobiliarios por cuenta propia"
"683"="Actividades inmobiliarias por cuenta de terceros"
"691"="Actividades jur�dicas"
"692"="Actividades de contabilidad, tenedur�a de libros, auditor�a y asesor�a fiscal"
"701"="Actividades de las sedes centrales"
"702"="Actividades de consultor�a de gesti�n empresarial"
"711"="Servicios t�cnicos de arquitectura e ingenier�a y otras actividades relacionadas con el asesoramiento t�cnico"
"712"="Ensayos y an�lisis t�cnicos"
"721"="Investigaci�n y desarrollo experimental en ciencias naturales y t�cnicas"
"722"="Investigaci�n y desarrollo experimental en ciencias sociales y humanidades"
"731"="Publicidad"
"732"="Estudio de mercado y realizaci�n de encuestas de opini�n p�blica"
"741"="Actividades de dise�o especializado"
"742"="Actividades de fotograf�a"
"743"="Actividades de traducci�n e interpretaci�n"
"749"="Otras actividades profesionales, cient�ficas y t�cnicas n.c.o.p."
"750"="Actividades veterinarias"
"771"="Alquiler de veh�culos de motor"
"772"="Alquiler de efectos personales y art�culos de uso dom�stico"
"773"="Alquiler de otra maquinaria, equipos y bienes tangibles"
"774"="Arrendamiento de la propiedad intelectual y productos similares, excepto trabajos protegidos por los derechos de autor"
"781"="Actividades de las agencias de colocaci�n"
"782"="Actividades de las empresas de trabajo temporal"
"783"="Otra provisi�n de recursos humanos"
"791"="Actividades de agencias de viajes y operadores tur�sticos"
"799"="Otros servicios de reservas y actividades relacionadas con los mismos"
"801"="Actividades de seguridad privada"
"802"="Servicios de sistemas de seguridad"
"803"="Actividades de investigaci�n"
"811"="Servicios integrales a edificios e instalaciones"
"812"="Actividades de limpieza"
"813"="Actividades de jardiner�a"
"821"="Actividades administrativas y auxiliares de oficina"
"822"="Actividades de los centros de llamadas"
"823"="Organizaci�n de convenciones y ferias de muestras"
"829"="Actividades de apoyo a las empresas n.c.o.p."
"841"="Administraci�n P�blica y de la pol�tica econ�mica y social"
"842"="Prestaci�n de servicios a la comunidad en general"
"843"="Seguridad Social obligatoria"
"851"="Educaci�n preprimaria"
"852"="Educaci�n primaria"
"853"="Educaci�n secundaria"
"854"="Educaci�n postsecundaria"
"855"="Otra educaci�n"
"856"="Actividades auxiliares a la educaci�n"
"861"="Actividades hospitalarias"
"862"="Actividades m�dicas y odontol�gicas"
"869"="Otras actividades sanitarias"
"871"="Asistencia en establecimientos residenciales con cuidados sanitarios"
"872"="Asistencia en establecimientos residenciales para personas con discapacidad intelectual, enfermedad mental y drogodependencia"
"873"="Asistencia en establecimientos residenciales para personas mayores y con discapacidad f�sica"
"879"="Otras actividades de asistencia en establecimientos residenciales"
"881"="Actividades de servicios sociales sin alojamiento para personas mayores y con discapacidad"
"889"="Otros actividades de servicios sociales sin alojamiento"
"900"="Actividades de creaci�n, art�sticas y espect�culos"
"910"="Actividades de bibliotecas, archivos, museos y otras actividades culturales"
"920"="Actividades de juegos de azar y apuestas"
"931"="Actividades deportivas"
"932"="Actividades recreativas y de entretenimiento"
"941"="Actividades de organizaciones empresariales, profesionales y patronales"
"942"="Actividades sindicales"
"949"="Otras actividades asociativas"
"951"="Reparaci�n de ordenadores y equipos de comunicaci�n"
"952"="Reparaci�n de efectos personales y art�culos de uso dom�stico"
"960"="Otros servicios personales"
"970"="Actividades de los hogares como empleadores de personal dom�stico"
"981"="Actividades de los hogares como productores de bienes para uso propio"
"982"="Actividades de los hogares como productores de servicios para uso propio"
"990"="Actividades de organizaciones y organismos extraterritoriales"
"000"="No contesta"
;

* Tablas 4.........................;
value N_999NC

999="No contesta"
;
value N_99NC

99="No contesta"
;
 
 * 3) VINCULAR FORMATOS A LA BASE DE DATOS;
  DATA ROutput.&siglas_periodo.&conFormato;
		set ROutput.&siglas_periodo;
 
 FORMAT CCAA $TCCAA.;
FORMAT ESTRATO $TESTRAT.;
FORMAT SEXO $TSEXO.;
FORMAT EDAD N_999NC.;
FORMAT NADULTOS N_99NC.;
FORMAT NMENORES N_99NC.;
FORMAT A9 $TSINO.;
FORMAT A8 $T8A.;
FORMAT A5_otra $T5A_otr.;
FORMAT A10 $T10A.;
FORMAT A11 $T11A.;
FORMAT A12 $T12A.;
FORMAT B13 $T13B.;
FORMAT B14 $TSINOC.;
FORMAT B15_2 $T15CNAE.;
FORMAT B16_2 $T16CNO.;
FORMAT B17 $T17B.;
FORMAT B18 $TSINOC.;
FORMAT B19a_2 $T15CNAE.;
FORMAT B19b_2 $T15CNAE.;
FORMAT B20a_2 $T16CNO.;
FORMAT B20b_2 $T16CNO.;
FORMAT B21a $T21aB.;
FORMAT B21b $T21bB.;
FORMAT CLASE_PR $TCLASE.;
FORMAT C22_1 $TVIV.;
FORMAT C22_2 $TVIV.;
FORMAT C22_3 $TVIV.;
FORMAT C22_4 $TVIV.;
FORMAT C22_5 $TVIV.;
FORMAT C22_6 $TVIV.;
FORMAT C22_7 $TVIV.;
FORMAT C22_8 $TVIV.;
FORMAT C22_9 $TVIV.;
FORMAT D23_1 $TSINO.;
FORMAT D23_2 $TSINO.;
FORMAT D23_3 $TSINO.;
FORMAT D23_4 $TSINO.;
FORMAT D23_5 $TSINO.;
FORMAT D23_6 $TSINO.;
FORMAT D23_7 $TSINO.;
FORMAT D23_8 $TSINO.;
FORMAT D23_9 $TSINO.;
FORMAT D23_10 $TSINO.;
FORMAT D23_11 $TSINO.;
FORMAT D24 $T24D.;
FORMAT INGRESOS $TINGRES.;

RUN;
/* FIN PROGRAMA: Microdatos en SAS: ESdEhogar_2023.sas*/
